from fastapi import APIRouter, HTTPException
from app.services.market_service import get_market_analysis, generate_recommendation

router = APIRouter(prefix="/market", tags=["Market"])

VALID_ASSETS = ["stock", "gold", "silver", "platinum"]


@router.get("/{asset_types}")
def market_analysis(asset_types: str):
    # Case-insensitive + multiple assets support
    requested = [a.strip().lower() for a in asset_types.split(",")]

    invalid = [a for a in requested if a not in VALID_ASSETS]
    if invalid:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid asset(s): {invalid}. Valid options: {VALID_ASSETS}"
        )

    results = {}
    for asset in requested:
        result = get_market_analysis(asset)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        results[asset] = result

    response = {"assets": results}

    # Recommendation only when multiple assets requested
    if len(requested) > 1:
        response["recommendation"] = generate_recommendation(results)

    return response